//
//  TiReminders.h
//  titanium-reminders
//
//  Created by Your Name
//  Copyright (c) 2021 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiReminders.
FOUNDATION_EXPORT double TiRemindersVersionNumber;

//! Project version string for TiReminders.
FOUNDATION_EXPORT const unsigned char TiRemindersVersionString[];

#import "TiRemindersModuleAssets.h"
